var grid = document.getElementById("grid")
var grid2 = document.getElementById("grid2")
var grid3 = document.getElementById("grid3")
var grid4 = document.getElementById("grid4")
var grid5 = document.getElementById("grid5")
var grid7 = document.getElementById("grid7")
var imgCheck = document.getElementById("hdneitor")
for (let i=0; i<200;i++)
{
	let x=document.querySelector (".grid")
		let div = document.createElement ("div")
		div.id="n"+(i+1)
		div.classList.add("negro")
		div.style.gridArea = "n"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<200;i++)
{
	let x=document.querySelector (".grid")
		let div = document.createElement ("div")
		div.id="m"+(i+1)
		div.classList.add("marron")
		div.style.gridArea = "m"+(i+1)
		x.appendChild(div)
}

//GRID 2
for (let i=0; i<110;i++)
{
	let x=document.querySelector("#grid2")
		let div = document.createElement ("div")
		div.id="n"+(i+1)
		div.classList.add("negro")
		div.style.gridArea = "n"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<100;i++)
{
	let x=document.querySelector ("#grid2")
		let div = document.createElement ("div")
		div.id="m"+(i+1)
		div.classList.add("marron")
		div.style.gridArea = "m"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<100;i++)
{
	let x=document.querySelector ("#grid2")
		let div = document.createElement ("div")
		div.id="r"+(i+1)
		div.classList.add("rosa")
		div.style.gridArea = "r"+(i+1)
		x.appendChild(div)
}

//GRID 3
for (let i=0; i<200;i++)
{
	let x=document.querySelector("#grid3")
		let div = document.createElement ("div")
		div.id="n"+(i+1)
		div.classList.add("negro")
		div.style.gridArea = "n"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<100;i++)
{
	let x=document.querySelector ("#grid3")
		let div = document.createElement ("div")
		div.id="m"+(i+1)
		div.classList.add("marron")
		div.style.gridArea = "m"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<100;i++)
{
	let x=document.querySelector ("#grid3")
		let div = document.createElement ("div")
		div.id="r"+(i+1)
		div.classList.add("rosa")
		div.style.gridArea = "r"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<100;i++)
{
	let x=document.querySelector ("#grid3")
		let div = document.createElement ("div")
		div.id="ro"+(i+1)
		div.classList.add("rojo")
		div.style.gridArea = "ro"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<100;i++)
{
	let x=document.querySelector ("#grid3")
		let div = document.createElement ("div")
		div.id="a"+(i+1)
		div.classList.add("amarillo")
		div.style.gridArea = "a"+(i+1)
		x.appendChild(div)
}
// GRID 4 - 5
for (let i=0; i<155;i++)
{
	let x=document.querySelector("#grid4")
		let div = document.createElement ("div")
		div.id="n"+(i+1)
		div.classList.add("negro")
		div.style.gridArea = "n"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<150;i++)
{
	let x=document.querySelector ("#grid4")
		let div = document.createElement ("div")
		div.id="m"+(i+1)
		div.classList.add("marron")
		div.style.gridArea = "m"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<100;i++)
{
	let x=document.querySelector ("#grid4")
		let div = document.createElement ("div")
		div.id="r"+(i+1)
		div.classList.add("rosa")
		div.style.gridArea = "r"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<155;i++)
{
	let x=document.querySelector("#grid5")
		let div = document.createElement ("div")
		div.id="n"+(i+1)
		div.classList.add("negro")
		div.style.gridArea = "n"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<150;i++)
{
	let x=document.querySelector ("#grid5")
		let div = document.createElement ("div")
		div.id="m"+(i+1)
		div.classList.add("marron")
		div.style.gridArea = "m"+(i+1)
		x.appendChild(div)
}

// GRID 6
for (let i=0; i<200;i++)
{
	let x=document.querySelector ("#grid7")
		let div = document.createElement ("div")
		div.id="n"+(i+1)
		div.classList.add("negro")
		div.style.gridArea = "n"+(i+1)
		x.appendChild(div)
}
for (let i=0; i<200;i++)
{
	let x=document.querySelector ("#grid7")
		let div = document.createElement ("div")
		div.id="m"+(i+1)
		div.classList.add("marron")
		div.style.gridArea = "m"+(i+1)
		x.appendChild(div)
}


function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  async function fLengua() {
	  imgCheck.checked = false
	  fImg()
	  for( var i = 0 ; i < 3 ; i++){
	await sleep(500);
	grid.style.display = "none";
	grid2.style.display = "grid";
	grid3.style.display = "none";
	grid4.style.display = "none";
	grid5.style.display = "none";
	grid7.style.display = "none";
	await sleep(500);
	grid.style.display = "grid";
	grid2.style.display = "none";
	grid3.style.display = "none";
	grid4.style.display = "none";
	grid5.style.display = "none";
	grid7.style.display = "none";
	}
  }
  
  document.getElementById("bLengua").addEventListener("click",fLengua)


	

  
 function fImg(){
	 if(document.getElementById("hdneitor").checked){
		document.getElementById("hd").style.display = "inline";
		grid.style.display = "none"
		grid2.style.display = "none"
		grid3.style.display = "none"
		grid4.style.display = "none"
		grid5.style.display = "none"
		grid7.style.display = "none"
	 }else{
		document.getElementById("hd").style.display = "none";
		grid.style.display = "grid"
		grid2.style.display = "none"
		grid3.style.display = "none"
		grid4.style.display = "none"
		grid5.style.display = "none"
		grid7.style.display = "none"
	 }
	 
 } 
 document.getElementById("hdneitor").addEventListener("click",fImg)

 async function fAdopt(){
	imgCheck.checked = false
	fImg()
	document.getElementById("nav").style.display = "none"
	grid3.style.display = "grid"
	grid2.style.display = "none"
	grid.style.display = "none"
	grid4.style.display = "none";
	grid5.style.display = "none";
	grid7.style.display = "none";
	document.getElementById("love").style.display = "inline";
	await sleep(100)
	alert("You have a new friend <3")
}
 document.getElementById("adopt").addEventListener("click",fAdopt)


 function fSit(){
	imgCheck.checked = false
	fImg()
	if(document.getElementById("sit").checked){
	   grid4.style.display = "grid"
	   grid.style.display = "none"
	   grid2.style.display = "none";
	   grid3.style.display = "none";
	   grid5.style.display = "none";
	   grid7.style.display = "none";
	}else{
	  grid4.style.display = "none"
	   grid.style.display = "grid"
	   grid2.style.display = "none";
	   grid3.style.display = "none";
	   grid5.style.display = "none";
	   grid7.style.display = "none";
	}
	
} 
document.getElementById("sit").addEventListener("click",fSit)

async function colita() {
	imgCheck.checked = false
	fImg()
	for( var i = 0 ; i < 3 ; i++){
  await sleep(150);
  grid.style.display = "none";
  grid7.style.display = "grid";
  grid5.style.display = "none";
  grid4.style.display = "none";
  grid2.style.display = "none";
  grid3.style.display = "none";
  await sleep(150);
  grid.style.display = "none";
  grid2.style.display = "none";
  grid3.style.display = "none";
  grid4.style.display = "none";
  grid7.style.display = "none";
  grid5.style.display = "grid";
  await sleep (150);
  grid.style.display ="none";
  grid2.style.display = "none";
  grid3.style.display = "none";
  grid4.style.display = "none";
  grid5.style.display ="none";
  grid7.style.display ="grid";
  await sleep (150);
  grid.style.display ="grid";
  grid2.style.display = "none";
  grid3.style.display = "none";
  grid4.style.display = "none";
  grid5.style.display ="none";
  grid7.style.display ="none";
  }
}

document.getElementById("cola").addEventListener("click",colita)